<?php
include('language.php');

$language = 'ar';
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<!-- index-2.html  29 Nov 2019 03:32:54 GMT -->

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="Construction & Building HTML Template" />
    <meta name="author" content="AlexaTheme" />
    <title>العمودي</title>
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png" />
    <link rel="stylesheet" href="css/fontawesome.min.css" />
    <link rel="stylesheet" href="css/themify-icons.css" />
    <link rel="stylesheet" href="css/elegant-line-icons.css" />
    <link rel="stylesheet" href="css/elegant-font-icons.css" />
    <link rel="stylesheet" href="css/flaticon.css" />
    <link rel="stylesheet" href="css/animate.min.css" />
    <!-- <link rel="stylesheet" href="css/bootstrap.min.css" /> -->
    <link rel="stylesheet" href="css/bootstrap.rtl.css" />
    <link rel=" stylesheet" href="css/slick.css" />
    <link rel="stylesheet" href="css/slider-ar.css" />
    <link rel="stylesheet" href="css/odometer.min.css" />
    <link rel="stylesheet" href="css/venobox/venobox.css" />
    <link rel="stylesheet" href="css/owl.carousel.css" />
    <!-- <link rel="stylesheet" href="css/main.css" /> -->
    <link rel="stylesheet" href="css/main_ar.css" />
    <link rel="stylesheet" href="css/responsive.css" />
    <script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>

</head>

<body>
    <!--[if lt IE 8]>
      <p class="browserupgrade">
        You are using an <strong>outdated</strong> browser. Please
        <a href="http://browsehappy.com/">upgrade your browser</a> to improve
        your experience.
      </p>
    <![endif]-->
    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div>
    <header class="header">
        <div class="primary-header">
            <div class="container">
                <div class="primary-header-inner">
                    <div class="header-logo mb-2 mt-2">
                        <a href="index.php"><img src="img/logo.png" /></a>
                    </div>
                    <div class="header-menu-wrap">
                        <ul class="dl-menu">
                            <li><a href="index.php"> <?php echo $top_nav[$language]['Home'] ?> </a></li>
                            <li><a href="index.php#about"><?php echo $top_nav[$language]['about'] ?></a></li>
                            <li><a href="team.php"><?php echo $top_nav[$language]['our_team'] ?></a></li>
                            <li><a href="projects.php"><?php echo $top_nav[$language]['our_projects'] ?></a></li>
                            <li><a href="contact.php"><?php echo $top_nav[$language]['contact'] ?></a></li>
                            <li><a href="en/index.php"> English </a></li>

                        </ul>
                    </div>
                    <div class="header-right">
                        <!-- <a class="menu-btn" href="#">Request a Quote</a> -->

                        <div class="mobile-menu-icon">
                            <div class="burger-menu">
                                <div class="line-menu line-half first-line"></div>
                                <div class="line-menu"></div>
                                <div class="line-menu line-half last-line"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>